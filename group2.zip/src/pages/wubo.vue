<template>
  <div>
      <h1>吴波的页面</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>

</style>
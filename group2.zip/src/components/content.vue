<template>
  <div class="content-body">
      子路由实体
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>